import './Main.css'
import Banner from './MainPage/Banner';


const Main=()=>{
    return(
        <>
        <Banner />
        </>
    )
}

export default Main;